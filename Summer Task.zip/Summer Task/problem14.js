
 let Number=(prompt("Enter the number"))
 let Factorial=1;

for(let i=1;i<=Number;i++)
{
Factorial=Factorial*i
}
console.log("Factorial is "+ " "+ Factorial)

