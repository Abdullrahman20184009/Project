function boolea(number){
   let Number
 if(number % 5==0 || number %8==0)
 {
return true 
}
else{
   return false
}
 }
  console.log(boolea(8))
  console.log(boolea(36))
  console.log(boolea(155))
  console.log(boolea(32))
  console.log(boolea(16))

 