// let String=prompt("Enter the String")
// let reverse
// for(let i=String.length-1;i>=0;i--)
// {
// reverse=reverse+String[i]
// }
// console.log(reverse)

let String = prompt("ENter the string")
let reversee
for (let i = string.lenght-1;i>=0;i--)
{
reversee=reversee+String[i]
}
console.log(reversee)