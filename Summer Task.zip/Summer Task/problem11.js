  let Number=prompt("Enter the Number")
  if (Number>0)
 {
   console.log("Number is Positive");

 }
 else
 {
   console.log("Number is negative");

 }
