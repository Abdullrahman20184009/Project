const FirstNumber=parseInt(prompt("FirstNumber"))
const SecondNumber=parseInt(prompt("SecondNumber"))
const sum = FirstNumber+SecondNumber
console.log("Sum is "+ " "+ sum)
