

let  x=prompt("Enter the number!!!") ;
if(x%2==0)
{
   console.log(x +" "+"is even numver");
}
else{
   
   console.log(x + " " +"is odd numver");}

