
  let FirstNumber
  let SecondNumber
  let sum
   sum=FirstNumber+SecondNumber
  function boolean(FirstNumber,SecondNumber,sum)
  {
   sum=FirstNumber+SecondNumber

  if(FirstNumber==50||SecondNumber==50||sum==50)
  {
    //return true
    console.log("true")
  }
 else
 {
  //return false
  console.log("false")
 }
}
console.log(boolean(50,0))
console.log(boolean(25,0))
console.log(boolean(25,25))
console.log(boolean(30,20))
console.log(boolean(0,50))

