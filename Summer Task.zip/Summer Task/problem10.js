let rows=6
for(let i=0;i<=rows;i++)
{
   for(let i=0;i<=i;i++)
   {
   document.write('*')
}
document.write("<br>")
}
