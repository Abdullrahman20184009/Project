let Number=prompt("Enter the Number")
let total=0
for(let i=0;i<=Number;i++)
{
total=total+i;
}
console.log("Sum = "+ total);