
 let Radius=parseFloat(prompt("Radius"))
  let Area, Circumference;
 Area= 3.14*Radius*Radius
 Circumference=2*3.14*Radius
 console.log("Area is "+ " "+ Area +" \n"+"Circumference is " + " "+ Circumference )
 